#!/usr/bin/env python3

import argparse
import os

from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor

from rl_training.f110_speed_env import F110SpeedEnv


def add_common_env_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--min_speed", type=float, default=0.5)
    parser.add_argument("--max_speed", type=float, default=4.0)
    parser.add_argument("--max_speed_index_delta", type=float, default=0.05, help="Deprecated compatibility arg")
    parser.add_argument("--max_speed_delta_per_step_mps", type=float, default=0.10)
    parser.add_argument("--max_delta_speed_mps", type=float, default=0.30)
    parser.add_argument("--residual_correction_scale", type=float, default=0.25, help="Deprecated compatibility arg")
    parser.add_argument("--curvature_gain", type=float, default=2.0)
    parser.add_argument("--rule_curvature_lookahead_points", type=int, default=3)
    parser.add_argument("--model_curvature_short_points", type=int, default=10)
    parser.add_argument("--model_curvature_mid_points", type=int, default=40)
    parser.add_argument("--model_curvature_long_points", type=int, default=80)
    parser.add_argument("--max_episode_steps", type=int, default=5000)
    parser.add_argument("--target_lap_steps", type=int, default=5000)

    # Safe random starts: base point is on the raceline; optional lateral/yaw
    # noise is clipped and should be kept small.
    parser.add_argument("--random_start_along_centerline", action="store_true")
    parser.add_argument("--random_start_min_index", type=int, default=-1)
    parser.add_argument("--random_start_max_index", type=int, default=-1)
    parser.add_argument("--start_lateral_noise_std", type=float, default=0.0)
    parser.add_argument("--start_lateral_noise_max", type=float, default=0.05)
    parser.add_argument("--start_yaw_noise_std", type=float, default=0.0)
    parser.add_argument("--start_yaw_noise_max", type=float, default=0.05)
    parser.add_argument("--start_xy_noise_std", type=float, default=0.0)
    parser.add_argument("--start_xy_noise_max", type=float, default=0.05)

    # Observation noise is training-side robustness noise. It perturbs only what
    # PPO sees, not the simulator state and not the reward calculation.
    parser.add_argument("--obs_cte_noise_std", type=float, default=0.0)
    parser.add_argument("--obs_heading_noise_std", type=float, default=0.0)
    parser.add_argument("--obs_speed_noise_std", type=float, default=0.0)
    parser.add_argument("--random_seed", type=int, default=None)


def make_env(args) -> F110SpeedEnv:
    return F110SpeedEnv(
        map_path=args.map_path,
        map_ext=args.map_ext,
        centerline_csv=args.centerline_csv,
        start_pose=(args.sx, args.sy, args.stheta),
        min_speed=args.min_speed,
        max_speed=args.max_speed,
        max_speed_index_delta=args.max_speed_index_delta,
        max_speed_delta_per_step_mps=args.max_speed_delta_per_step_mps,
        max_delta_speed_mps=args.max_delta_speed_mps,
        residual_correction_scale=args.residual_correction_scale,
        max_episode_steps=args.max_episode_steps,
        target_lap_steps=args.target_lap_steps,
        curvature_gain=args.curvature_gain,
        rule_curvature_lookahead_points=args.rule_curvature_lookahead_points,
        model_curvature_short_points=args.model_curvature_short_points,
        model_curvature_mid_points=args.model_curvature_mid_points,
        model_curvature_long_points=args.model_curvature_long_points,
        random_start_along_centerline=args.random_start_along_centerline,
        random_start_min_index=args.random_start_min_index,
        random_start_max_index=args.random_start_max_index,
        start_lateral_noise_std=args.start_lateral_noise_std,
        start_lateral_noise_max=args.start_lateral_noise_max,
        start_yaw_noise_std=args.start_yaw_noise_std,
        start_yaw_noise_max=args.start_yaw_noise_max,
        start_xy_noise_std=args.start_xy_noise_std,
        start_xy_noise_max=args.start_xy_noise_max,
        obs_cte_noise_std=args.obs_cte_noise_std,
        obs_heading_noise_std=args.obs_heading_noise_std,
        obs_speed_noise_std=args.obs_speed_noise_std,
        random_seed=args.random_seed,
        use_speed_dependent_lookahead=True,
    )


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--map_path", required=True)
    parser.add_argument("--map_ext", required=True)
    parser.add_argument("--centerline_csv", required=True)

    parser.add_argument("--sx", type=float, required=True)
    parser.add_argument("--sy", type=float, required=True)
    parser.add_argument("--stheta", type=float, required=True)

    parser.add_argument("--total_timesteps", type=int, default=50000)
    parser.add_argument("--model_dir", default="models")
    parser.add_argument("--model_name", default="ppo_speed_agent")
    add_common_env_args(parser)

    # PPO hyperparameters kept configurable for faster experiments.
    parser.add_argument("--learning_rate", type=float, default=2e-4)
    parser.add_argument("--n_steps", type=int, default=2048)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--gamma", type=float, default=0.995)
    parser.add_argument("--gae_lambda", type=float, default=0.95)
    parser.add_argument("--clip_range", type=float, default=0.15)
    parser.add_argument("--ent_coef", type=float, default=0.001)

    args = parser.parse_args()
    os.makedirs(args.model_dir, exist_ok=True)

    env = Monitor(make_env(args))

    model = PPO(
        policy="MlpPolicy",
        env=env,
        verbose=1,
        learning_rate=args.learning_rate,
        n_steps=args.n_steps,
        batch_size=args.batch_size,
        gamma=args.gamma,
        gae_lambda=args.gae_lambda,
        clip_range=args.clip_range,
        ent_coef=args.ent_coef,
        tensorboard_log=os.path.join(args.model_dir, "tensorboard"),
    )

    model.learn(total_timesteps=args.total_timesteps)

    save_path = os.path.join(args.model_dir, args.model_name)
    model.save(save_path)

    print("")
    print("Training finished.")
    print(f"Saved model to: {save_path}.zip")


if __name__ == "__main__":
    main()
